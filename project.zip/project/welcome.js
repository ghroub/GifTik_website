firebase.auth().onAuthStateChanged((user)=>{
    if(!user){
        location.replace("LogIn.html")             
    }else{      
      
var db = firebase.firestore();
db.collection('BusinessOwner').get().then((snapshot)=>{
    getInfo(snapshot.docs);
});

function getInfo(data){
  data.forEach(doc => {
     
     var info = doc.data();
     if(info.BOEmail == user.email && info.Status == false){
         alert("لم يتم قبولك بعد، الرجاء إعادة محاولة تسجيل الدخول في وقت لاحق")
     location.replace("GifTikHome.html") 
     }
      
      if(info.BOEmail == user.email && info.Status == true){
     // console.log(info.BOName);
      document.getElementById("user2").innerHTML = info.BOName + " أهلًا بك " 
      }    

});
}            
           
    }
})

function logout(){
    firebase.auth().signOut()
}
