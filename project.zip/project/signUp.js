document.getElementById("loginForm").addEventListener("submit",(event)=>{
    event.preventDefault()
})

const db = firebase.firestore()


firebase.auth().onAuthStateChanged((user)=>{
    if(user){
        location.replace("BOSignUpForm.html")

    }
})

function signUp(){
    
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value

    firebase.auth().createUserWithEmailAndPassword(email, password)
    .catch((error) => {

        let msg = error.message

        if (msg == "Password should be at least 6 characters "){
            document.getElementById("error").innerHTML ="يجب أن تتكون كلمة المرور من 6 خانات على الأقل"
        }

        if (msg == "The email address is already in use by another account."){
            document.getElementById("error").innerHTML =".عنوان البريد الإلكتروني قيد الاستخدام بالفعل من قبل حساب آخر"
        }
       
    });
    
    
}

