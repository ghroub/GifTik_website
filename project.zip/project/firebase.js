const firebaseConfig = {
    apiKey: "AIzaSyAvXo36IHu5KVGkwOwakiO-9w5qJxsnoPU",
    authDomain: "giftik2-1abf0.firebaseapp.com",
    databaseURL: "https://giftik2-1abf0-default-rtdb.firebaseio.com",
    projectId: "giftik2-1abf0",
    storageBucket: "giftik2-1abf0.appspot.com",
    messagingSenderId: "306137565048",
    appId: "1:306137565048:web:49005dd5c4ce2a9318ea8d",
    measurementId: "G-YXLR2B3N3Z"
  };
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
