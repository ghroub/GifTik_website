document.getElementById("loginForm").addEventListener("submit",(event)=>{
    event.preventDefault()
})

const db = firebase.firestore()


function insertData(){
    firebase.auth().onAuthStateChanged((user) => {
        if(user){

            var userID = user.uid;
            var userEmail = user.email;

            const data = {
                    BOName: document.getElementById('BOName').value,
                    BOPhoneNumber: document.getElementById('BOPhoneNumber').value,
                    StoreName: document.getElementById('StoreName').value,
                    BOWebsite: document.getElementById('BOWebsite').value,
                    BOCertificate :document.getElementById('BOCertificate').value,
                    BOEmail: userEmail,
                    Status: false
                };

                var r = confirm("هل انت متأكد من صحة المعلومات ولا تحتاج الى تعديل؟");
                
                if(r){
                    const res = db.collection('BusinessOwner').doc(userID).set(data);
                    alert("تم تسجيلك بنجاح، يرجى الانتظار حتى وصول بريد إلكتروني يُفيد بتفعليك في منصة قفتك ")
                    
                    
                    
                    // Then user should log out and go to GifTikHome.html AUTOMATICALLY



                }
          
        }else{
            console.log("User not logged in or has just logged out.");
        }
        
      });


    


}





